## Running the tests for elm-test itself

1. `cd` into this directory
2. `npm install`
3. `elm package install --yes`
4. `npm test`
