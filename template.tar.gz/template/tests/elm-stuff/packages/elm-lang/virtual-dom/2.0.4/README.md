# Virtual DOM for Elm

A virtual DOM implementation that backs Elm's core libraries for [HTML](http://package.elm-lang.org/packages/elm-lang/html/latest/) and [SVG](http://package.elm-lang.org/packages/elm-lang/svg/latest/). You should almost certainly use those higher-level libraries directly.

It is pretty fast! You can read about that [here](http://elm-lang.org/blog/blazing-fast-html-round-two).
