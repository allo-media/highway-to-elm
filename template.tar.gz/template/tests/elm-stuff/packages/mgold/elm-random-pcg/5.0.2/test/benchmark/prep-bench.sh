#!/bin/sh

set -e

elm-make --yes --output bench.js Bencher.elm
