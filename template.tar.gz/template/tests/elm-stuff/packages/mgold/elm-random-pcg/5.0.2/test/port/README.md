# Port test

```
elm make Test.elm --output=elm.js
```

This shows how to hook up ports to the random number generator to produce different values each time.
