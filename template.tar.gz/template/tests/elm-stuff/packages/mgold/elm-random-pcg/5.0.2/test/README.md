# Random.Pcg Tests

The tests in this directory are one-off simple programs to confirm that certain functions aren't obviously wrong.
Heavyweight statistical tests are under `dieharder`. Benchmarks (using a 0.16 benchmarking lib) are in `benchmark`.
